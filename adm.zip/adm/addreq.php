<?php
	$name = "\n".$_REQUEST['Name']."\n";
	$email = "\n".$_REQUEST['Email']."\n";
	$phone = "\n".$_REQUEST['Phone']."\n";
	$emsg = "\n".$_REQUEST['Details']."\n";
	mail('alectramell@gmail.com', '[ADM] CONTACT REQUEST', 'New Contact Request from: '.$email."\n".'Name: '.$name."\n".'Email: '.$email."\n".'Phone: '.$phone."\n".'Message: '.$emsg."\n");
?>

<html>
<head>
<title>
ADM | Contact Us
</title>
<META http-equiv="REFRESH" content="7; url=http://www.apollondatametrics.com/index.php">
<link rel="icon" type="image/png" href="img/favicon.png">
</head>
<body bgcolor="#000000">

<br />

<center>
<font face="monospace" color="#ffffff" size="6"><b>Your Message Has been Sent!</b></font>
</center>
<center>
<font face="monospace" color="#ffffff" size="5"><b>..We will contact you within 1 to 3 business days..</b></font>
</enter>
<br />
<br />
<center>
<font face="monospace" color="#ffffff" size="4"><b>Redirecting Home..</b></font>
</center>

</body>
</html>



<?php
	/* CONTACT FORM */
?>
<html>
<head>
<title>
ADM | Contact Us
</title>
<script type="text/javascript" src="js/index.js"></script>
<link rel="icon" type="image/png" href="img/favicon.png">
</head>
<body bgcolor="#000000">

<img src="img/infoICONdark.png" width="64px" align="center" onmouseover="this.src='img/infoICON.png';this.width='64';homeSelect();" onmouseout="this.src='img/infoICONdark.png';this.width='64';" onclick="parent.location = 'http://www.apollondatametrics.com/index.php';">

<center>
<font face="comfortaa" size="7" color="#ffffff"><b>CONTACT US</b></font>
</center>

<center>
<table border="0" width="70%">
<tr>
<td>
<center>
<font face="comfortaa" size="5" color="#ffffff"><b>..Let us know what you need.. Even if its simply a question of interest, front-end, back-end, software development, any code is our craft..</b></font>
</center>
</tr>
</td>
</table>
</center>

<center>
<form method="POST" action="http://www.apollondatametrics.com/addreq.php">
<p><font face="comfortaa" size="5" color="#ffffff"><b>NAME</b></font>
<input type="text" name="Name" size="20"></p>
<p><font face="comfortaa" size="5" color="#ffffff"><b>EMAIL</b></font>
<input type="text" name="Email" size="20"></p>
<p><font face="comfortaa" size="5" color="#ffffff"><b>PHONE</b></font>
<input type="text" name="Phone" size="20"></p>
<br />
<font face="comfortaa" size="5" color="#ffffff"><b>..MESSAGE..</b></font>
<p><textarea name="Details" rows="15" cols="75" style="font-family:comfortaa;font-size:12pt;color:#000000;resize:none;"></textarea></p>
<p><input type="image" src="img/sendDARK.png" onmouseover="this.src='img/sendBLUE.png';" onmouseout="this.src='img/sendDARK.png';" border="0" alt="Submit" value="SEND" name="Submit" width="128px"></p>
</form>
</center>

<span class="skype-button rounded" data-contact-id="alectramell" data-text="SKYPE" data-color="#008DE6" style="position:fixed;top:40px;right:50px;"></span>
<script src="https://swc.cdn.skype.com/sdk/v1/sdk.min.js"></script>

</body>
</html>

<?php
	/* CONTACT FORM */
?>
<html>
<head>
<title>
ADM | Contact Us
</title>
<script type="text/javascript" src="js/index.js"></script>
<link rel="icon" type="image/png" href="http://www.apollondatametrics.com/img/favicon.png">
</head>
<body bgcolor="#000000">

<center>
<font face="comfortaa" size="7" color="#ffffff"><b>CONTACT US</b></font>
</center>

<center>
<form method="POST" action="http://www.apollondatametrics.com/addreqMOBILE.php">
<p><font face="comfortaa" size="5" color="#ffffff"><b>NAME</b></font>
<input type="text" name="Name" size="20"></p>
<p><font face="comfortaa" size="5" color="#ffffff"><b>EMAIL</b></font>
<input type="text" name="Email" size="20"></p>
<p><font face="comfortaa" size="5" color="#ffffff"><b>PHONE</b></font>
<input type="text" name="Phone" size="20"></p>
<br />
<font face="comfortaa" size="5" color="#ffffff"><b>..MESSAGE..</b></font>
<p><textarea name="Details" rows="10" cols="75" style="font-family:comfortaa;font-size:12pt;color:#000000;resize:none;"></textarea></p>
<p><input type="image" src="http://www.apollondatametrics.com/img/sendDARK.png" onmouseover="this.src='http://www.apollondatametrics.com/img/sendBLUE.png';" onmouseout="this.src='http://www.apollondatametrics.com/img/sendDARK.png';" border="0" alt="Submit" value="SEND" name="Submit" width="128px"></p>
</form>
</center>

<br />
<br />
<br />
<br />
<br />

</body>
</html>

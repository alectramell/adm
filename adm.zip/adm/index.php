<?php

	$XTITLE = 'ADM';
	$XCOLOR = '#000000';
	$XHOST = $_SERVER['REMOTE_HOST'];
	$XUSER = $_SERVER['REMOTE_ADDR'];
	$XDATE = date("m.d.Y");

	$cache = "pop/$XUSER.log";

	if (file_exists($cache)) {

		$startintro = '';
		file_put_contents($cache, "1");
		
	} else {
		
		$startintro = 'admToggleIntro();';
		file_put_contents($cache, "1");
	}

	/* Stamp Tracking */
	$domain = $_SERVER['SERVER_NAME'];
	$ustamp = $_SERVER['REMOTE_ADDR'];
	$dstamp = date("l jS \of F Y h:i:s A");
	$owner = "Apollon Data Metrics";
	$to = "www.apollondatametrics.com";
	$subject = "ADM >> ".$ustamp;
	$msg = "Someone from ".$ustamp." visited ".$domain." on ".$dstamp."\n";
	$headers = "From: ".$owner." <".$domain.">";

	/* Track to EMAIL */
	/* mail($to,$subject,$msg,$headers); */

	/* Track to Server */
	$file = 'traffic.log';
	$current = file_get_contents($file);
	$current .= $owner . "\n";
	$current .= $subject . "\n";
	$current .= $msg . "\n";
	$current .= "\n";
	file_put_contents($file, $current);
?>

<html>
<head>
<title>
<?php echo $XTITLE ?>
</title>
<script src="js/snowstorm.js"></script>
<script type="text/javascript" src="js/index.js"></script>
<META http-equiv="REFRESH" content="300; url=http://www.apollondatametrics.com/index.php">
<link rel="icon" type="image/png" href="img/favicon.png">
<link rel="stylesheet" type="text/css" href="css/main.css">
</head>
<body onload="darkTheme();<?php echo $startintro; ?>" bgcolor="<?php echo $XCOLOR ?>"
text="<?php echo $XCOLOR ?>"
link="<?php echo $XCOLOR ?>"
alink="<?php echo $XCOLOR ?>"
vlink="<?php echo $XCOLOR ?>">

<style type="text/css" id="tHeme">
	body {
    		background:#000000;
		background-size: cover;
		width:80%;
		height:80%;
		/* cursor:url(img/hand.cur), auto; */
		
	}
</style>

<!-- DATA -->
<!--img src="img/dataICONdark.png" width="90px" align="center" onmouseover="this.src='img/dataICON.png';this.width='90';dataHover();" onmouseout="this.src='img/dataICONdark.png';this.width='90';" onclick="dataSelect();alert('SORRY, OUR PORTFOLIO IS CURRENTLY UNDER CONSTRUCTION, CHECK BACK SOON..');" -->

<!-- CONTACT -->
<!--img src="img/emailICONdark.png" width="70px" align="center" onmouseover="this.src='img/emailICON.png';this.width='70';emailHover();" onmouseout="this.src='img/emailICONdark.png';this.width='70';" onclick="handOff();alert('+1 (971) 720 - 8023');" -->

<!-- parent.location = 'http://www.apollondatametrics.com/contact.php'; ALTERNATIVE FOR THE EVENT ABOVE (onclick) -->

<!-- ABOUT -->
<img src="img/infoICONdark.png" width="95px" align="center" onmouseover="this.src='img/infoICON.png';this.width='95';homeSelect();" onmouseout="this.src='img/infoICONdark.png';this.width='95';" onclick="admToggle();">

<!--img src="img/darkFIREFOX.png" width="95px" align="center" onmouseover="this.src='img/blueFIREFOX.png';this.width='95';aSelect();" onmouseout="this.src='img/darkFIREFOX.png';this.width='95';" onclick="parent.location = 'http://www.apollondatametrics.com/webapps.php';" -->

<!--img src="img/darkPAD.png" width="95px" align="center" onmouseover="this.src='img/bluePAD.png';this.width='95';bSelect();" onmouseout="this.src='img/darkPAD.png';this.width='95';" onclick="parent.location = 'http://www.apollondatametrics.com/games.php';" -->

<img src="img/iconATHENAdark.png" width="95px" align="center" onmouseover="this.src='img/iconATHENA.png';this.width='95';" onmouseout="this.src='img/iconATHENAdark.png';this.width='95';" onclick="athenaToggle();" title="ATHENA v1.0">

<img src="img/tuneinedark.png" width="95px" align="center" onmouseover="this.src='img/tuneinBLUE.png';this.width='95';" onmouseout="this.src='img/tuneinDARK.png';this.width='95';" onclick="toggleTuneIn();" title="Listen to the agencies favorite TuneIn stations" style="display:none;">

<img src="img/helpDARK.png" width="95px" align="center" onmouseover="this.src='img/helpBLUE.png';this.width='95';bSelect();" onmouseout="this.src='img/helpDARK.png';this.width='95';" onclick="parent.location = 'http://www.apollondatametrics.com/contact.php';">

<!-- div id="screenSpot">
<img src="img/fullscreenDARK.png" width="95px" style="position:absolute;top:81%;left:90%;" onmouseover="this.src='img/fullscreenBLUE.png';this.width='95';" onmouseout="this.src='img/fullscreenDARK.png';this.width='95';" onclick="openFullscreen();fitScreen();" id="screenOption" title="Fullscreen Mode">
</div -->

<br />
<br />
<br />
<br />

<script>

	snowStorm.autoStart = true;
	snowStorm.snowColor = '#005CA7';
	snowStorm.useTwinkleEffect = false;
	snowStorm.useMeltEffect = true;
	snowStorm.followMouse = false;
	snowStorm.snowStick = false;
	snowStorm.snowCharacter = '•';

</script>

<center>
<!--IPINFO <?php echo $XUSER ?> -->
<!--DTINFO <?php echo $XDATE ?> -->
</center>

<img id="imgLOGO" src="img/admGRAD.png" onclick="admToggle();">

<img id="openMenu" src="img/lightMenu.png" style="display:none;" onclick="admToggle();">

<img id="openMenuAthena" src="img/lightMenuAthena.png" style="display:none;" onclick="athenaToggle();">

<span class="skype-button rounded" data-contact-id="alectramell" data-text="SKYPE" data-color="#008DE6" style="position:fixed;top:40px;right:50px;"></span>
<script src="https://swc.cdn.skype.com/sdk/v1/sdk.min.js"></script>

<iframe id="tuneinRadio" src="https://tunein.com/embed/player/s248539/" style="position:fixed;bottom:10px;right:5px;width:400px;height:100px;display:none;" scrolling="no" frameborder="no"></iframe>

</body>
</html>

<?php

	$XTITLE = 'ADM | Games';
	$XCOLOR = '#000000';
	$XHOST = $_SERVER['REMOTE_HOST'];
	$XUSER = $_SERVER['REMOTE_ADDR'];
?>

<html>
<head>
<title>
<?php echo $XTITLE ?>
</title>
<script type="text/javascript" src="js/index.js"></script>
<META http-equiv="REFRESH" content="300; url=http://www.apollondatametrics.com/games.php">
<link rel="icon" type="image/png" href="img/favicon.png">
</head>
<body onload="darkThemeGames();" bgcolor="<?php echo $XCOLOR ?>"
text="<?php echo $XCOLOR ?>"
link="<?php echo $XCOLOR ?>"
alink="<?php echo $XCOLOR ?>"
vlink="<?php echo $XCOLOR ?>">

<style type="text/css" id="tHeme">
	body {
    		background-image: url("img/darkBGgames1.png");
		background-repeat: no-repeat;
    		background-position: top center;
    		background-attachment: fixed;
		background-size: cover;
		width:90%;
		height:90%;
		cursor:url(img/hand.cur), auto;
		overflow:hidden;
	}
</style>

<!-- DATA -->
<!--img src="img/dataICONdark.png" width="150px" align="center" onmouseover="this.src='img/dataICON.png';this.width='90';dataHover();" onmouseout="this.src='img/dataICONdark.png';this.width='90';" onclick="dataSelect();alert('SORRY, OUR PORTFOLIO IS CURRENTLY UNDER CONSTRUCTION, CHECK BACK SOON..');" -->

<!-- CONTACT -->
<!--img src="img/emailICONdark.png" width="70px" align="center" onmouseover="this.src='img/emailICON.png';this.width='70';emailHover();" onmouseout="this.src='img/emailICONdark.png';this.width='70';" onclick="handOff();alert('+1 (971) 720 - 8023');" -->

<!-- parent.location = 'http://www.apollondatametrics.com/contact.php'; ALTERNATIVE FOR THE EVENT ABOVE (onclick) -->

<!-- ABOUT -->
<img src="img/infoICONdark.png" width="95px" align="center" onmouseover="this.src='img/infoICON.png';this.width='95';" onmouseout="this.src='img/infoICONdark.png';this.width='95';" onclick="parent.location = 'http://www.apollondatametrics.com/index.php'">

<img src="img/darkFIREFOX.png" width="95px" align="center" onmouseover="this.src='img/blueFIREFOX.png';this.width='95';" onmouseout="this.src='img/darkFIREFOX.png';this.width='95';" onclick="parent.location = 'http://www.apollondatametrics.com/webapps.php';">

<img src="img/darkPAD.png" width="95px" align="center" onmouseover="this.src='img/bluePAD.png';this.width='95';" onmouseout="this.src='img/darkPAD.png';this.width='95';" onclick="parent.location = 'http://www.apollondatametrics.com/games.php';">

<br />
<br />
<br />

<center>
<!--font face="monospace" color="#ffffff" size="7" align="middle"><b>YOUR IP IS</b> <?php echo $XUSER ?></font -->
</center>

</body>
</html>

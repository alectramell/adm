#!/bin/bash

clear

XSTAT=$(curl -s http://www.apollondatametrics.com/traffic.log)

clear

echo "$XSTAT" | grep --color="always" -A3 "Apollon Data Metrics"

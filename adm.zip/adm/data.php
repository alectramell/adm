<?php
	$XHOST = $_SERVER['REMOTE_HOST'];
	$XUSER = $_SERVER['REMOTE_ADDR'];
	$XDATE = date("m-d-Y");
?>

<!--XDATE <?php echo $XDATE ?> -->
